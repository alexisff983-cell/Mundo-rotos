const http = require('http');
const fs = require('fs');
const path = require('path');
const { WebSocketServer, WebSocket } = require('ws');
const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  if (pathname === '/') pathname = '/index.html';
  const file = path.join(PUBLIC, pathname.replace(/^\/+/, ''));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('No encontrado'); }
    const ext = path.extname(file);
    const types = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.json':'application/json; charset=utf-8' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control':'no-store' });
    res.end(data);
  });
});
const wss = new WebSocketServer({ server });
const rooms = new Map();
const clients = new Map();
const MAX_PLAYERS = 10;
function code() { let s; do { s = Math.random().toString(36).slice(2,8).toUpperCase(); } while (rooms.has(s)); return s; }
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function playerList(room) { return [...room.players.values()].map(p => ({...p})); }
function state(room) { return { code: room.code, players: playerList(room) }; }
function broadcast(room, obj) { for (const p of room.players.values()) send(p.ws, obj); }
function remove(ws) {
  const client = clients.get(ws); if (!client) return;
  clients.delete(ws);
  if (!client.code) return;
  const room = rooms.get(client.code); if (!room) return;
  room.players.delete(client.id);
  broadcast(room, { type:'playerLeft', playerId:client.id });
  if (room.players.size === 0) rooms.delete(room.code);
  else broadcast(room, { type:'roomState', state:state(room) });
}
wss.on('connection', ws => {
  const id = Math.random().toString(36).slice(2,10);
  clients.set(ws, { id, code:null });
  send(ws, { type:'welcome', playerId:id });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw.toString()); } catch { return send(ws,{type:'error',message:'Mensaje inválido.'}); }
    const client = clients.get(ws); if (!client) return;
    const safePlayer = () => ({ id, ws, name:String(m.name||'Aventurero').slice(0,16), power:String(m.power||'Fuego').slice(0,24), color:/^#[0-9a-fA-F]{6}$/.test(m.color||'')?m.color:'#6ad7ff', x:Number.isFinite(m.x)?Math.max(18,Math.min(782,m.x)):390, y:Number.isFinite(m.y)?Math.max(52,Math.min(478,m.y)):260 });
    if (m.type === 'createRoom') {
      if (client.code) return send(ws,{type:'error',message:'Ya estás en una sala. Recarga la página para crear otra.'});
      const c = code(), room = { code:c, players:new Map() }; rooms.set(c, room);
      client.code = c; room.players.set(id, safePlayer());
      send(ws,{type:'roomCreated',code:c,players:1,state:state(room)});
      return;
    }
    if (m.type === 'joinRoom') {
      if (client.code) return send(ws,{type:'error',message:'Ya estás en una sala. Recarga la página para cambiar de sala.'});
      const c = String(m.code||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
      const room = rooms.get(c);
      if (!room) return send(ws,{type:'error',message:'No existe una sala con ese código. Pide al anfitrión que cree una.'});
      if (room.players.size >= MAX_PLAYERS) return send(ws,{type:'error',message:'La sala está llena (máximo 10 jugadores).'});
      client.code = c; room.players.set(id, safePlayer());
      send(ws,{type:'joined',code:c,players:room.players.size,state:state(room)});
      broadcast(room,{type:'roomState',state:state(room)});
      return;
    }
    if (m.type === 'move') {
      if (!client.code) return;
      const room = rooms.get(client.code), p = room && room.players.get(id); if (!p) return;
      p.x = Number.isFinite(m.x)?Math.max(18,Math.min(782,m.x)):p.x;
      p.y = Number.isFinite(m.y)?Math.max(52,Math.min(478,m.y)):p.y;
      p.name = String(m.name||p.name).slice(0,16); p.power = String(m.power||p.power).slice(0,24);
      if (/^#[0-9a-fA-F]{6}$/.test(m.color||'')) p.color = m.color;
      broadcast(room,{type:'roomState',state:state(room)});
    }
  });
  ws.on('close', () => remove(ws));
  ws.on('error', () => remove(ws));
});
server.listen(PORT, '0.0.0.0', () => console.log(`Mundos Rotos activo en http://localhost:${PORT}`));
